package Order.miniproject.controller;

import Order.miniproject.domain.Member;
import Order.miniproject.domain.dto.LoginDto;
import Order.miniproject.domain.dto.MemberDto;
import Order.miniproject.repository.MemberRepository;
import Order.miniproject.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

@Controller
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/members")
public class MemberController {
  private final MemberService memberService;

  @GetMapping("/addMember") // 회원가입 - 회원
  public String addMember(Model model) {
    MemberDto member = new MemberDto();
    model.addAttribute("member", member);
    return "members/addMember";
  }

  @PostMapping("/addMember")
  public String addMembersProcess(@ModelAttribute("member") MemberDto memberDto) {
    Long id = memberService.join(memberDto);
    System.out.println(memberDto);
//    System.out.println(id + ": 번 회원가입 완료");
    return "redirect:/members/login";
  }

  @GetMapping("/login") // 회원 등록-관리자
  public String login(Model model) {
    LoginDto login = new LoginDto();
    model.addAttribute("login", login);
    return "members/login";
  }
  @PostMapping("/login")
  public String loginProcess(@ModelAttribute("login") LoginDto loginDto,
                             HttpServletResponse resp) {
    Member loginMember = memberService.login(loginDto);
    if(loginMember == null) {
      //로그인 실패
      log.info("==== 로그인 post ==== 실패");
      return "members/login";
    } else {
      // 로그인 성공
      // 쿠키를 응답에 답에서 클라이언트로 전성
      log.info("==== 로그인 post ==== 성공");
      Cookie cookie = new Cookie("memberId", String.valueOf(loginMember.getId()));
      resp.addCookie(cookie);
      return "redirect:/home";
    }
  }
}
