package Order.miniproject.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.PatternMatchUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.UUID;

@Slf4j
public class LoginFilter implements Filter {

  private static final String[] whiteLists = {"/" , "/home" ,
    "/members/login" , "/members/addMember" , "/members/logout" ,
    "/css/*"};


// 로그필터 (LogFilter)  달리 '/*'
// 로그인 필터(LoginFilter)는 적용을 할 URI - /items/* ,/orders/*
  // 적용하지 않을 URI --/ , /home, /members/login , /members/addMember, /members/logout, /css/* ,
  //
  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    HttpServletRequest httpRequest = (HttpServletRequest) request; //downcasting
    HttpServletResponse httpResponse = (HttpServletResponse) response;
    String requestURI = httpRequest.getRequestURI();
    String uuid = UUID.randomUUID().toString();

    log.info("로그인 인증 필터 시작 : [{}], [{}]", uuid, requestURI);
    //whitelist 안에 있는 uri로 접근하는 경우에는 로그인 체크를 하지 않음
    //whitelist 를 제외한 uri로 접근하는 경우에는 로그인 체크를 함
    try {
      if(!PatternMatchUtils.simpleMatch(whiteLists, requestURI)) {
        HttpSession session = httpRequest.getSession(false);
        if(session == null || session.getAttribute("loginMember") == null) {
         httpResponse.sendRedirect("/members/login?redirectURL=" + requestURI);
          return; // 미인증 사용자를 login 하도록 내보내면서 요청 ur; 정보를 함께 넘겨주기
        }
      }
      chain.doFilter(request, response);
    } catch (Exception e) {
      throw e;
    } finally {
      log.info("로그인 인증 필터 종료 : [{}], [{}]", uuid, requestURI);
    }

  }
}
