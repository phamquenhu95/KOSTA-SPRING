package Order.miniproject.domain;

public enum OrderStatus {
  ORDER,
  CANCEL
}
