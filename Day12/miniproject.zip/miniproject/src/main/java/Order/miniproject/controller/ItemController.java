package Order.miniproject.controller;

import Order.miniproject.domain.Book;
import Order.miniproject.domain.Item;
import Order.miniproject.domain.dto.BookDto;
import Order.miniproject.domain.dto.SessionMember;
import Order.miniproject.service.ItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/items")
public class ItemController {
  private final ItemService itemService; // @Autowired 사용하면 final 없애버려야 함
  @GetMapping("/addItem")
  //로그인 체크 여부
  public String addItem() {
    return "items/addItem";
  }

  @PostMapping("/addItem")
  public String addItemProcess(@ModelAttribute BookDto bookDto) {
    //로그인 체크 여부
    Book book = new Book();
    book.setName(bookDto.getName());
    book.setPrice(bookDto.getPrice());
    book.setStockQuantity(bookDto.getStockQuantity());
    book.setAuthor(bookDto.getAuthor());
    book.setIsbn(bookDto.getIsbn());
    itemService.saveItem(book); //upcasting
    return "redirect:/items/itemList";

  }
  @GetMapping("/itemList")
  public String itemList(
      HttpServletRequest request,
      Model model) {
    HttpSession session = request.getSession(false);
    if(session == null) {
      return "redirect:/home";
//    model.addAttribute("items",itemService.findAllItems());
//    return "items/itemList";
  }
    // 세션이 존재하면
    SessionMember findMember = (SessionMember)session.getAttribute("loginMember");
    if(findMember == null) {
      return "redirect:/home";
    }else{
      model.addAttribute("items", itemService.findAllItems());
      return "items/itemList";
    }
  }

  @GetMapping("/itemInfo/{id}")
  public String itemInfo(@PathVariable Long id,
                         Model model) {
    //로그인 체크 여부 로직
    Book item = (Book)itemService.findItem(id);

    BookDto bookDto = new BookDto(item.getId(), item.getName(), item.getPrice(), item.getStockQuantity(),
        item.getAuthor(), item.getIsbn());

    model.addAttribute("item",bookDto);
    return "items/itemInfo";
  }
  @GetMapping("/updateItem/{id}")
  public String updateItem(@PathVariable Long id,
                           Model model) {
    Book item = (Book)itemService.findItem(id);
    BookDto bookDto = new BookDto(item.getId(), item.getName(), item.getPrice(), item.getStockQuantity(),
        item.getAuthor(), item.getIsbn());
    model.addAttribute("item", item);
    return "items/updateItem";
  }

  @PostMapping("/updateItem/{id}")
  //로그인 체크 여부 로직
  public String updateItemProcess(@PathVariable Long id,
                                  @ModelAttribute BookDto bookDto) {
    itemService.updateItem(id, bookDto);
    return "redirect:/items/itemList";
  }

//  @GetMapping("/updateItem/{id}")
//  public String itemUpdate(@PathVariable Long id,
//                           Model model) {
//    model.addAttribute("item",itemService.getItem(id));
//    model.addAttribute("message","수정화면입니다.");
//    model.addAttribute("message1","수정하려는 필드의 ");
//    model.addAttribute("message2","값을 수정하세요");
//    return "items/updateItem";
//  }
//  @PostMapping("/updateItem/{id}")
//  public String itemUpdateProcess(@PathVariable Long id,
//                                  @ModelAttribute ItemDto itemDto,
//                                  RedirectAttributes redirectAttributes) {
//    itemService.updateItem(id, itemDto);
//    redirectAttributes.addAttribute("message2", true);
//    return "redirect:/items/itemList";
//  }
}